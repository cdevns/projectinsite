<template>
  <div>
    <h2>Insite Dashboard</h2>
  </div>
</template>