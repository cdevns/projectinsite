<template>
  <div>
    <h2>PIE CHART</h2>
    <svg width="500" height="400" />
    {{getterSubscribers}}
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
  computed: {
    ...mapGetters(["getterSubscribers"])
  },
  methods: {
    ...mapActions(["actionSubscribersData"]),
    renderPieChart(data) {
      // DATA RECEIVING CODE
      console.log("3: ", data);

      // PIE CHART CODE TO BE WRITTEN WITH THIS DATA COMES
    }
  },
  mounted() {
    this.actionSubscribersData();
    this.renderPieChart(this.getterSubscribers);
  }
};
</script>
